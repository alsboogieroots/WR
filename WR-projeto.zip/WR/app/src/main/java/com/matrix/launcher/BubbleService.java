package com.matrix.launcher;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

public class BubbleService extends Service {
    WindowManager manager; TextView bubble; WindowManager.LayoutParams params;
    @Override public IBinder onBind(Intent i) { return null; }
    @Override public int onStartCommand(Intent i,int flags,int id) {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY; }
        NotificationManager nm=getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("bubble","Botão Matrix",NotificationManager.IMPORTANCE_LOW));
        PendingIntent open=PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent stop=PendingIntent.getService(this,1,new Intent(this,BubbleService.class).setAction("stop"),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        if (i!=null && "stop".equals(i.getAction())) { stopSelf(); return START_NOT_STICKY; }
        startForeground(1,new Notification.Builder(this,"bubble").setSmallIcon(android.R.drawable.ic_menu_view).setContentTitle("Matrix ativo").setContentText("Toque no coelho para escolher um launcher.").setContentIntent(open).addAction(new Notification.Action.Builder(null,"Desativar",stop).build()).setOngoing(true).build());
        if (bubble!=null) return START_NOT_STICKY;
        manager=getSystemService(WindowManager.class);
        int size=(int)(60*getResources().getDisplayMetrics().density);
        params=new WindowManager.LayoutParams(size,size,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);
        params.gravity=Gravity.TOP|Gravity.LEFT; params.x=20; params.y=260;
        bubble=new TextView(this); bubble.setText("🐇\nRABBIT"); bubble.setTextSize(12); bubble.setTextColor(MainActivity.GREEN); bubble.setGravity(Gravity.CENTER); bubble.setContentDescription("Escolher launcher. Arraste para mover.");
        GradientDrawable bg=new GradientDrawable(); bg.setShape(GradientDrawable.OVAL); bg.setColor(Color.rgb(5,18,10)); bg.setStroke(2,MainActivity.GREEN); bubble.setBackground(bg);
        bubble.setOnClickListener(v -> startActivity(new Intent(this,MainActivity.class).putExtra("choose",true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)));
        bubble.setOnTouchListener(new View.OnTouchListener() {
            float downX,downY; int startX,startY; boolean moved;
            public boolean onTouch(View v,android.view.MotionEvent e) {
                if(e.getAction()==MotionEvent.ACTION_DOWN) { downX=e.getRawX(); downY=e.getRawY(); startX=params.x; startY=params.y; moved=false; return true; }
                if(e.getAction()==MotionEvent.ACTION_MOVE) { float dx=e.getRawX()-downX,dy=e.getRawY()-downY; if(Math.hypot(dx,dy)>8*getResources().getDisplayMetrics().density)moved=true;
                    params.x=Math.max(0,Math.min(getResources().getDisplayMetrics().widthPixels-params.width,startX+(int)dx)); params.y=Math.max(0,Math.min(getResources().getDisplayMetrics().heightPixels-params.height,startY+(int)dy)); manager.updateViewLayout(bubble,params); return true; }
                if(e.getAction()==MotionEvent.ACTION_UP) { if(!moved)v.performClick(); return true; } return true;
            }
        });
        try { manager.addView(bubble,params); } catch(RuntimeException e) { bubble=null; stopSelf(); }
        return START_NOT_STICKY;
    }
    @Override public void onDestroy() { if(bubble!=null) { manager.removeView(bubble); bubble=null; } super.onDestroy(); }
}
