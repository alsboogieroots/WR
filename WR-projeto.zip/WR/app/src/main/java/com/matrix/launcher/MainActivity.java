package com.matrix.launcher;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.Color;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    static final int GREEN = Color.rgb(0,255,102);
    static Intent homeIntent() { return new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME); }
    static void settings(Context c) {
        try { c.startActivity(new Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }
        catch (ActivityNotFoundException e) { c.startActivity(new Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }
    }
    static Button button(Context c, String label) {
        Button b = new Button(c); b.setText(label); b.setTextColor(GREEN);
        b.setAllCaps(false); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(12,35,20)));
        return b;
    }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout box = new LinearLayout(this); box.setOrientation(1); box.setPadding(28,40,28,24);
        box.setBackgroundColor(Color.rgb(5,10,7));
        TextView title = new TextView(this); title.setText("01 10 01 11 00\n\nFOLLOW THE\nWHITE RABBIT\n\nWR • MATRIX"); title.setTextColor(GREEN); title.setTextSize(27); box.addView(title);
        TextView info = new TextView(this); info.setText("\nAtive o coelho flutuante para abrir um launcher instalado. Para manter a escolha, use Launcher padrão.\n"); info.setTextColor(Color.rgb(150,210,170)); box.addView(info);
        Button enable = button(this,"Ativar botão flutuante"); box.addView(enable);
        enable.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())));
                Toast.makeText(this,"Permita aparecer sobre outros apps e volte para ativar.",Toast.LENGTH_LONG).show();
            } else {
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED)
                    requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},1);
                startForegroundService(new Intent(this,BubbleService.class));
            }
        });
        Button choose = button(this,"Abrir launcher instalado"); box.addView(choose); choose.setOnClickListener(v -> chooser());
        Button defaults = button(this,"Escolher launcher padrão"); box.addView(defaults); defaults.setOnClickListener(v -> settings(this));
        Button stop = button(this,"Desativar botão flutuante"); box.addView(stop); stop.setOnClickListener(v -> stopService(new Intent(this,BubbleService.class)));
        ScrollView scroll = new ScrollView(this); scroll.addView(box); setContentView(scroll);
        if (getIntent().getBooleanExtra("choose",false)) chooser();
    }
    void chooser() {
        List<ResolveInfo> found = getPackageManager().queryIntentActivities(homeIntent(),0);
        List<ResolveInfo> apps = new ArrayList<>(); Set<String> seen = new HashSet<>();
        for (ResolveInfo r : found) if (!r.activityInfo.packageName.equals("android") && seen.add(r.activityInfo.packageName)) apps.add(r);
        apps.sort((a,b) -> a.loadLabel(getPackageManager()).toString().compareToIgnoreCase(b.loadLabel(getPackageManager()).toString()));
        String[] labels = new String[apps.size()+1];
        for (int i=0;i<apps.size();i++) labels[i]=apps.get(i).loadLabel(getPackageManager()).toString();
        labels[apps.size()]="Configurar launcher padrão";
        new AlertDialog.Builder(this).setTitle("Escolha sua realidade").setItems(labels,(d,which) -> {
            if (which==apps.size()) { settings(this); return; }
            ResolveInfo r=apps.get(which);
            try { startActivity(homeIntent().setComponent(new ComponentName(r.activityInfo.packageName,r.activityInfo.name)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }
            catch (RuntimeException e) { Toast.makeText(this,"Não foi possível abrir. Escolha nas configurações.",Toast.LENGTH_LONG).show(); settings(this); }
        }).setNegativeButton("Voltar",null).show();
    }
}
