# WR

Projeto Android nativo, sem bibliotecas externas de interface. Android 8 ou posterior.

Abra esta pasta no Android Studio com JDK 17 ou posterior, instale o SDK 35 e use Build > Build APK(s). O APK debug assinado será gerado em app/build/outputs/apk/debug/app-debug.apk.

Instale no celular, abra WR, toque em Ativar botão flutuante e conceda a permissão de aparecer sobre outros apps. Volte e toque em Ativar novamente. O botão pode ser arrastado. Toque para ver os launchers instalados, incluindo White Rabbit e XOS quando registrados como aplicativos de início.

Abrir um launcher não muda o padrão. Para isso, use Escolher launcher padrão e confirme no Android. Não é preciso conceder acessibilidade nem root. Não há permissão de internet.

No Infinix, se o sistema encerrar o botão em segundo plano, permita a execução em segundo plano nas configurações de bateria do app. A notificação e a tela principal permitem desativar o botão.

Estado: projeto preparado, sem compilação ou teste no aparelho. Ferramentas de compilação Android indisponíveis no ambiente de criação.
